package com.microservice.backupmanager.controller.dto.response;

public record DownloadUrlResponse(
        String url
) {
}
