package com.microservice.backupmanager.infrastructure.persistence.mappers;

import com.microservice.backupmanager.domain.BackupHistory;
import com.microservice.backupmanager.infrastructure.persistence.entities.BackupHistoryEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface BackupHistoryMapper {

    @Mapping(source = "marketId", target = "market.id")
    BackupHistoryEntity toEntity(BackupHistory domain);

    @Mapping(source = "market.id", target = "marketId")
    BackupHistory toDomain(BackupHistoryEntity entity);
}
